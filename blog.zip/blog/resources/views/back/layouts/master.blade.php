@include('back.layouts.header')
@include('back.layouts.menu')
@yield('content')
@include('back.layouts.footer')
