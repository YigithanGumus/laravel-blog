<?php $__env->startSection('title', $page->title); ?>
<?php $__env->startSection('bg', $page->image); ?>
<?php $__env->startSection('content'); ?>

    <div class="col-md-10 col-lg-8 col-xl-7" style="margin-bottom: 30px;">
        <?php echo $page->content; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/front/page.blade.php ENDPATH**/ ?>