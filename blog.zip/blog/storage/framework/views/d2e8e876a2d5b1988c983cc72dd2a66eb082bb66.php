<?php $__env->startSection('title', $article->title); ?>
<?php $__env->startSection('bg', $article->image); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8" style="margin-bottom: 30px;">
        <?php echo $article->content; ?>

    </div>
    <?php echo $__env->make('front.widgets.categoryWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/front/single.blade.php ENDPATH**/ ?>