<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Post preview-->
    <div class="post-preview">
        <a href="<?php echo e(route('single',[$article->getCategory->slug,$article->slug])); ?>">
            <h2 class="post-title" style="border-bottom:0.1pt solid rgb(196, 192, 192);">
                <?php echo e($article->title); ?>

            </h2>
            <img src="<?php echo e($article->image); ?>" alt="" class="img-fluid">
            <h3 class="post-subtitle">
                <?php echo e(Str::limit($article->content, 75)); ?>


            </h3>
        </a>
        <div class="row">
            <div class="col-md-6" style="margin-top:-25px;">
                <p class="post-meta"> Kategori:
                    <a href="#"><?php echo e($article->getCategory->name); ?></a>
                </p>
            </div>
            <div class="col-md-6" style="margin-top:-25px;">
                <p class="post-meta">
                    <span><?php echo e($article->created_at->diffForHumans()); ?></span>
                </p>
            </div>
        </div>
        <span style="color:Red;">Okunma Sayısı : <?php echo e($article->hit); ?></span>
    </div>
    <?php if(!$loop->last): ?>
        <hr>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\blog\resources\views/front/widgets/postWidget.blade.php ENDPATH**/ ?>