<?php $__env->startSection('title', 'Tüm Makaleler'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo $__env->yieldContent('title'); ?>
                <span class="float-right"><?php echo e($articles->count()); ?> makale bulundu.
                    <a href="<?php echo e(route('admin.trashed.article')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-trash"></i> Silinen Makaleler</a>
                </span>
            </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Fotoğraf</th>
                            <th>Makale Başlığı</th>
                            <th>Kategori</th>
                            <th>Görüntülenme Sayısı</th>
                            <th>Oluşturulma Tarihi</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img src="<?php echo e($article->image); ?>" width="200">
                                </td>
                                <td>
                                    <?php echo e($article->title); ?>

                                </td>
                                <td>
                                    <?php echo e($article->getCategory->name); ?>

                                </td>
                                <td>
                                    <?php echo e($article->hit); ?>

                                </td>
                                <td>
                                    <?php echo e($article->created_at->diffForHumans()); ?>

                                </td>
                                <td>
                                    <input class="switch" article-id="<?php echo e($article->id); ?>" type="checkbox" data-on="Aktif"
                                        data-off="Pasif" data-onstyle="success" data-offstyle="danger"
                                        <?php if($article->status == 1): ?> checked <?php endif; ?> data-toggle="toggle">
                                </td>
                                <td>
                                    <a target="_blank" href="<?php echo e(route('single',[$article->getCategory->slug,$article->slug])); ?>" title="Görüntüle" class="btn btn-sm btn-success"><i
                                            class="fa fa-eye"></i></a>
                                    <a href="<?php echo e(route('admin.makaleler.edit', $article->id)); ?>" title="Düzenle"
                                        class="btn btn-sm btn-primary"><i class="fa fa-pen"></i></a>
                                    <a href="<?php echo e(route('admin.delete.article', $article->id)); ?>" title="Sil"
                                        class="btn btn-sm btn-success"><i class="fa fa-times"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <script>
        $(function() {
            $('.switch').change(function() {
                id = $(this)[0].getAttribute('article-id');
                statu = $(this).prop('checked');
                $.get("<?php echo e(route('admin.switch')); ?>", {
                    id: id,
                    statu: statu
                }, function(data, status) {});
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/back/articles/index.blade.php ENDPATH**/ ?>