<?php $__env->startSection('title', 'Silinmiş Makaleler'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo $__env->yieldContent('title'); ?>
                <span class="float-right"><?php echo e($articles->count()); ?> makale bulundu.
                    <a href="<?php echo e(route('admin.makaleler.index')); ?>" class="btn btn-primary btn-sm">
                        Aktif Makaleler</a>
                </span>
            </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Fotoğraf</th>
                            <th>Makale Başlığı</th>
                            <th>Kategori</th>
                            <th>Görüntülenme Sayısı</th>
                            <th>Oluşturulma Tarihi</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img src="<?php echo e($article->image); ?>" width="200">
                                </td>
                                <td>
                                    <?php echo e($article->title); ?>

                                </td>
                                <td>
                                    <?php echo e($article->getCategory->name); ?>

                                </td>
                                <td>
                                    <?php echo e($article->hit); ?>

                                </td>
                                <td>
                                    <?php echo e($article->created_at->diffForHumans()); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.recover.article', $article->id)); ?>" title="Silmekten Kurtar"
                                        class="btn btn-sm btn-primary"><i class="fa fa-recycle"></i></a>

                                    <a href="<?php echo e(route('admin.hard.delete.article', $article->id)); ?>" title="Sil"
                                        class="btn btn-sm btn-success"><i class="fa fa-times"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/back/articles/trashed.blade.php ENDPATH**/ ?>