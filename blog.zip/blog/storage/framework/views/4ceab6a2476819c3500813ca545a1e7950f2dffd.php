<?php $__env->startSection('title', $category->name.' Kategorisi |'.count($articles).' yazı bulundu.'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-9  col-xl-7">

        <?php echo $__env->make('front.widgets.categoryTextWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <?php echo $__env->make('front.widgets.categoryWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/front/category.blade.php ENDPATH**/ ?>