<?php $__env->startSection('title', 'İletişim'); ?>
<?php $__env->startSection('bg',
    'https://img.freepik.com/premium-photo/website-internet-contact-us-page-concept-with-phone-chat-email-icons-symbol-telephone-mail-mobile-phone-website-page-contact-us-wide-web-banner-copy-space-blue-background_256259-2730.jpg'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <p>Bizimle iletişime geçebilirsiniz.</p>
        <form method="post" action="<?php echo e(route('contact.post')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="pwd" class="form-label">Ad Soyad:</label>
                <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" id="pwd" placeholder="Adınız ve soyadınızı giriniz"
                    name="name">
            </div>
            <div class="mb-3 mt-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" value="<?php echo e(old('email')); ?>" id="email" placeholder="E-Postanızı giriniz" name="email">
            </div>

            <div class="mb-3 mt-3">
                <label for="konu" class="form-label">Konu:</label>
                <select name="topic" class="form-control" id="konu">
                    <option <?php if(old('topic')=="Bilgi"): ?> selected <?php endif; ?>>Bilgi</option>
                    <option <?php if(old('topic')=="Genel"): ?> selected <?php endif; ?>>Genel</option>
                    <option <?php if(old('topic')=="Destek"): ?> selected <?php endif; ?>>Destek</option>
                </select>
            </div>
            <div class="mb-3 mt-3">
                <label for="message" class="form-label">Mesaj:</label>
                <textarea name="message" id="message" rows="10" class="form-control"><?php echo e(old('message')); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Gönder</button>
        </form>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <b>
                    İletişim Bilgileri:
                </b>
            </div>
            <div class="card-body">
                <b>Adres:</b><br> İstanbul <br>
                <b>Telefon Bilgileri:</b> <br> +905355977965 <br>
                <b>Mail Adresi:</b> <br> yigithangumuss@gmail.com <br>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/front/contact.blade.php ENDPATH**/ ?>