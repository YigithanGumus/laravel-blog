<div class="col-md-3">
    <div class="card">
        <div class="card-header">
            KATEGORİLER
        </div>
        <ul class="list-group">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center  <?php if(Request::segment(2)==$category->slug): ?> active <?php endif; ?>">
                <a  <?php if(Request::segment(2)!=$category->slug): ?> href="<?php echo e(route('category', $category->slug)); ?>" <?php endif; ?>><?php echo e($category->name); ?></a>
                <span class="badge badge-primary badge-pill"
                    style="background-color: rgb(114, 110, 110);border-radius:30px;"><?php echo e($category->articleCount()); ?></span>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\blog\resources\views/front/widgets/categoryWidget.blade.php ENDPATH**/ ?>